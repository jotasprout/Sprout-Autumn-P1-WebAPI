﻿namespace Sensitive;
public class SensitiveVariables
{
    public static string dbpassword = "It$Alw@y5Autumn";
}

